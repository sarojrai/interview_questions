#comprehension
l1=[1,2,3,4,3,4,5,5]
l2=[]
for i in l1:
    x=i+100
    l2.append(x)
#print(l2)
r=[i+100 for i in l1 if i%2==0]
u={i+100 for i in l1 if i%2==0}
print(r)
print(u)
