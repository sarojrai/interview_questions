def add_number(*arg,**args):
    if len(arg)==3:
	x=arg[0]+arg[1]
        return x
    if len(arg)==2:
        y=arg[0]+arg[1]+args['n3']
	return y

z= add_number(10,20,n3=10)
print(z)

def addn_number(*arg1):
    sum=0
    length=len(arg1)
    print arg1
    for x in arg1:
        sum=sum+x
    return sum


n=addn_number(10,20,30,40)
print(n)
    
   
