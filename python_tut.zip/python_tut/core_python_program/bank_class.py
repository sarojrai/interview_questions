class Account():
    bankname='SBI'
    def __init__(self,name,pan):
        self.name=name
        self.pan=pan
        self.aaccount_no = name + pan
        self.passwoed = pan
        self.amount = 0
        self.open=1



    def credit(self,from_acc_no,to_acc_no,amt):
        self.creditamount=amt
        self.amount=self.amount+amt
        return amt
        #print " Rs %s  is credidit to account and total balance is %s" % (amt,self.amount)


    def debit(self,from_acc_no,to_acc_no,amt):
        self.debitamount = amt
        self.amount = self.amount - amt
        return self.debitamount
        #print " Rs %s  is debit to account and total balance is %s" % (amt, self.amount)

    def balance(self):
        self.amount
        return self.amount
        #print "total balance is %s" % (self.amount)

a1=Account('saroj','abc')
a2=Account('kisan','pqr')
print " --- welcome account 1--- \n"
if a1.open == 1:
    print("successfully open")

credit=a1.credit('abcabc','sarojabc',2000)
print " Rs %s  is credidit to account and total balance is %s" % (credit,a1.amount)
#credit=a1.credit('abcabc','sarojabc',1500)

debit=a1.debit('abcabc','sarojabc',1000)
print " Rs %s  is debit to account and total balance is %s" % (a1.debitamount, a1.amount)
balance =a1.balance()
print "total balance  for account a SBI is %s" % (a1.amount,Account.bankname)
print " --- welcome account 2 --- \n"
if a2.open == 1:
    print("successfully open")
balance =a2.balance()
print "total balance  for account b SBI is %s" % (a2.amount)

credit=a2.credit('abcabc','sarojabc',2000)
print " Rs %s  is credidit to account and total balance is %s" % (credit,a2.amount)
#credit=a1.credit('abcabc','sarojabc',1500)

debit=a2.debit('abcabc','sarojabc',1000)
print " Rs %s  is debit to account and total balance is %s" % (a2.debitamount, a2.amount)
balance =a2.balance()

print "total balance  for account a SBI is %s" % (a2.amount)








