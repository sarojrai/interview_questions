def add_number(*arg1):
    sum=0
    length=len(arg1)
    print arg1
    for x in arg1:
        sum=sum+x
    return sum
