def pyfunc(r):

    for x in range(r):
        # print((r-x-1),(2*x+1))
        print(' '*(r-x-1)+'*'*(2*x+1)) 

pyfunc(9)