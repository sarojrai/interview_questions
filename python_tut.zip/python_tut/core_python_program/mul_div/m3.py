def multiply_number(n1,n2):
    result=n1*n2
    return result