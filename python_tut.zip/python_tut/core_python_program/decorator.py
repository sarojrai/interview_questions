import time
def add(a,b):
    start=time.time()
    print"start",start
    c=pow(a,b)
    
    print c
    end=time.time()
    print "end",end
    e_time1=end-start
    print "difference",e_time1
    #return c
    

add(100,100)
