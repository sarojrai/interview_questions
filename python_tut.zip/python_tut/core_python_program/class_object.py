class Animal():

    type='something'
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def run(self):
        print "%s can  run" %(self.name)
        print "%s is %s year old"  %(self.name,self.age)

a1=Animal('cat',10)
a2=Animal('dog',10)

a1.run()