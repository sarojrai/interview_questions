"""
This file will manage business logic of backend app.
"""

from django.views import View
from django.shortcuts import render, redirect
from backend.forms import *
from django.http import JsonResponse
from django.http import HttpResponse, HttpResponseRedirect
from django.core.files.storage import FileSystemStorage
import os
from django.conf import settings
from django.contrib import messages
import time
import datetime
import csv
import itertools
from django.db import IntegrityError, transaction
from django.views.generic import TemplateView, ListView, FormView
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import csv
from django.db import connection
import collections
from backend.models import FileUploadHistory
from backend.models import ExpectedReturnSettings

import re
from ast import literal_eval
from django.db import connections



"""
Author: Saroj
   Date : 30-01-19
   Purpose : For PMS Upload insert
"""

class PmsUploadCreate(View):
    template_name = 'pms/create.html'
    form_class = PmsnavUploadForm

    def get(self, request, *args, **kwargs):
        """
        Return the list of all the active roles data.
        """
        # import pdb
        # pdb.set_trace()
        vclass =[]
        try:

            vclass = ExpectedReturnSettings.objects.filter(is_active=True).all()

        except Exception as e:
            print(e)
            # return []



        form= PmsnavUploadForm()
        return render(request, self.template_name, {'form': form,'vclass':vclass})

    @transaction.atomic
    def post(self, request, *args, **kwargs):

        # msg=''

        try:
            session_emp_code = request.session.get('employee')['employee_code']
        except Exception as e:
            session_emp_code = ''
        # form = self.form_class(request.POST)
        if request.method == 'POST':
            # error_color = ''
            # import pdb
            # pdb.set_trace()

            if 'nav_upload' in request.POST:
                #print('nav_upload')
                underlying = 0
                form_class = PmsnavUploadForm
                form = PmsnavUploadForm(request.POST, request.FILES)
                if form.is_valid():
                    csv_file = request.FILES["document"]
                    if csv_file.multiple_chunks():
                        form.errors['document'] =  "Uploaded file is too big (%.2f MB)." % (csv_file.size / (1000 * 1000),)
                        return render(request, self.template_name, {'url':'','form_error':form.errors})
                    file_data = csv_file.read().decode("utf-8",'ignore')

                    initial_obj = form.save(commit=False)
                    initial_obj.save()
                    document_url=initial_obj.document.url
                    if  file_data =='\n':
                        form.errors['document'] = "Uploaded file can not be  blank"
                        return render(request, self.template_name, {'url': '', 'form_error': form.errors})

                    lines = file_data.split("\n")
                    # loop over the lines and save them in db. If error , store as string and then display
                    data_dict = {}
                    data_list =[]

                    lines.remove(lines[0])
                    lines = list(filter(None, lines))


                    if not lines:
                        form.errors['document'] = "Uploaded file must have one record"
                        return render(request, self.template_name, {'url': '', 'form_error': form.errors})
                    # import pdb
                    # pdb.set_trace()
                    today_date = datetime.datetime.now().date()
                    # today_date = datetime.datetime.strptime(today_date, '%Y-%m-%d')
                    upload_error_dict = {}
                    upload_count_error=2
                    for line in lines:
                        fields = line.split(",")
                        fields = fields[:3]
                        if len(fields) != 3:

                            form.errors['document'] = "Incorrect Data in CSV File , Must have 3 columns "
                            return render(request, self.template_name,{'url': '', 'form_error': form.errors})

                        pms_code1 = fields[0].upper()
                        record_list = PmsDetails.objects.filter(is_active=True, pms_code=pms_code1).first()
                        if not record_list:
                            upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                           'pms_code': fields[0].upper(),
                                                                           'nav_date': fields[1],
                                                                           'description': 'Pms Code does not exists'}})
                        else:

                            try:
                                fields[1].replace(" ", "")
                                ip_format=datetime.datetime.strptime(fields[1], '%Y-%m-%d')
                                date1 = datetime.datetime.strptime(fields[1], '%Y-%m-%d').date()
                                if date1 > today_date:
                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'nav_date': fields[1],
                                                                                   'description': 'Future date is not allowed'}})
                                data_list.append([fields[0].upper(), fields[1]])
                            except ValueError:

                                upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                               'pms_code': fields[0].upper(),
                                                                               'nav_date': fields[1],
                                                                               'description': 'Incorrect Date Format, should be YYYY-MM-DD'}})



                        upload_count_error=upload_count_error+1

                    if  upload_error_dict:
                        response = HttpResponse(content_type='text/csv')
                        response['Content-Disposition'] = 'attachment; filename="nav_upload_error.csv"'
                        writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                        writer.writerow(['Row No','PMS Code', 'Nav Date', 'Description'])
                        for record in upload_error_dict.items():
                            csv_error_array = []
                            rowid=record[0]
                            msgtext=record[1]
                            csv_error_array.append(rowid)
                            csv_error_array.append(msgtext['pms_code'])
                            csv_error_array.append(msgtext['nav_date'])
                            csv_error_array.append(msgtext['description'])
                            writer.writerow(csv_error_array)

                        return response
                        # form.errors['document'] = "File is not getting uploaded.Please refer nav_upload_error.csv file for further details"
                        # return render(request, self.template_name, {'url': '', 'form_error': form.errors})

                    aa=len(data_list)
                    # data_list.sort()
                    cc=[x for n, x in enumerate(data_list) if x in data_list[:n]]
                    # new_datalist = list(data_list for data_list, _ in itertools.groupby(data_list))
                    # bb = len(new_datalist)

                    if cc:

                        response = HttpResponse(content_type='text/csv')
                        response['Content-Disposition'] = 'attachment; filename="nav_upload_error.csv"'
                        writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                        writer.writerow(['Row No', 'PMS Code', 'Nav Date', 'Description'])
                        for r in cc:
                            indices = [i for i, x in enumerate(data_list) if x == r]
                            indices = [x + 2 for x in indices]
                            csv_error_list = []
                            rowid = ", ".join(map(str, indices))
                            csv_error_list.append(rowid)
                            csv_error_list.append(r[0])
                            csv_error_list.append(r[1])
                            csv_error_list.append('Uploaded file has duplicate data')
                            writer.writerow(csv_error_list)

                        return response
                    else:
                        error_count=0

                        try:
                            with transaction.atomic():
                                upload_error_dict = {}
                                upload_count_error = 2
                                for line in lines:
                                    fields = line.split(",")
                                    pms_code1=fields[0].upper()
                                    data_dict["pms_code"] = record_list.id
                                    data_dict["pms_code"] = record_list.id
                                    data_dict["nav_date"] = fields[1]
                                    blank_list=['',None,'None']

                                    if fields[2] not in blank_list:
                                        data_dict["nav"] = round(float(fields[2]), 4)
                                    else:
                                        data_dict["nav"] = fields[2]


                                    form = PmsnavUploadInsertForm(data_dict)

                                    if form.is_valid():


                                        try:
                                            data = form.save(commit=False)
                                            data.document = document_url
                                            data.last_modified_by = session_emp_code
                                            data.modified_on = int(time.time())
                                            data.save()
                                        except Exception as e:
                                            upload_error_dict.update(
                                                {upload_count_error: {'row': upload_count_error,
                                                                      'pms_code': fields[0].upper(),
                                                                      'nav_date': fields[1],
                                                                      'description': e}})
                                            error_count += 1

                                    else:
                                        formdata_str = form.errors.as_json()
                                        formdata = literal_eval(formdata_str)

                                        for key, value in formdata.items():
                                            for x in value:
                                                erro_msg = key + ' : ' + x['message']
                                                upload_error_dict.update(
                                                    {upload_count_error: {'row': upload_count_error,
                                                                          'pms_code': fields[0].upper(),
                                                                          'nav_date': fields[1],
                                                                          'description': erro_msg}})

                                    upload_count_error = upload_count_error + 1

                                if upload_error_dict:

                                    response = HttpResponse(content_type='text/csv')
                                    response['Content-Disposition'] = 'attachment; filename="nav_upload_error.csv"'
                                    writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                                    writer.writerow(['Row No', 'PMS Code', 'Nav Date', 'Description'])
                                    for record in upload_error_dict.items():
                                        csv_error_array = []
                                        rowid = record[0]
                                        msgtext = record[1]
                                        csv_error_array.append(rowid)
                                        csv_error_array.append(msgtext['pms_code'])
                                        csv_error_array.append(msgtext['nav_date'])
                                        csv_error_array.append(msgtext['description'])
                                        writer.writerow(csv_error_array)
                                    return response

                                        # return render(request, self.template_name,
                                        #               {'url': '', 'form_error': form.errors})
                                if error_count > 0:
                                    msg = "Underlying uploaded has some error"
                                    raise IntegrityError

                                else:
                                    msg = "Underlying uploaded Successfully"
                                if error_count >0:
                                    msg = "Nav uploaded has some error"
                                    raise IntegrityError

                                else:
                                    msg = "Nav uploaded Successfully"




                        except IntegrityError:
                            pass
                            # handle_exception()

                        return render(request, self.template_name, {'url': '', 'form_error': form.errors, 'msg': msg})
            else:
                # print('underlying')
                today_date = datetime.datetime.now().date()
                underlying = 1
                form_class = PmsUnderlyingDocumentForm
                form = PmsUnderlyingDocumentForm(request.POST, request.FILES)
                if form.is_valid():
                    csv_file = request.FILES["document"]

                    if csv_file.multiple_chunks():
                        form.errors['document'] = "Uploaded file is too big (%.2f MB)." % (
                        csv_file.size / (1000 * 1000),)
                        return render(request, self.template_name,
                                      {'url': '', 'form_error': form.errors, 'underlying': 1})
                    file_data = csv_file.read().decode("utf-8",'ignore')

                    initial_obj = form.save(commit=False)
                    initial_obj.save()
                    document_url = initial_obj.document.url
                    if file_data == '\n':
                        form.errors['document'] = "Uploaded file can not be blank"
                        return render(request, self.template_name,
                                      {'url': '', 'form_error': form.errors, 'underlying': 1})

                    lines = file_data.split("\n")
                    # loop over the lines and save them in db. If error , store as string and then display
                    data_dict = {}
                    data_list = []
                    # data_list_per = []
                    data_dict_per = {}
                    lines.remove(lines[0])
                    lines = list(filter(None, lines))
                    if not lines:
                        form.errors['document'] = "Uploaded file must have one record"
                        return render(request, self.template_name,
                                      {'url': '', 'form_error': form.errors, 'underlying': 1})
                    upload_error_dict = {}
                    upload_count_error = 2
                    for line in lines:

                        fields = line.split(",")
                        fields = fields[:6]
                        if len(fields) != 6:
                            form.errors['document'] = "Incorrect Data in CSV File,Must have 6 columns"
                            return render(request, self.template_name,
                                          {'url': '', 'form_error': form.errors, 'underlying': 1})

                        pms_code1 = fields[0].upper()
                        record_list = PmsDetails.objects.filter(is_active=True, pms_code=pms_code1).first()

                        fields[4]=fields[4].replace("%", "")
                        fields[5]=fields[5].replace("%", "")

                        if not record_list:
                            upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                           'pms_code': fields[0].upper(),
                                                                           'nav_date': fields[1],
                                                                           'description': 'Pms Code does not exists'}})
                        else:

                            try:
                                fields[1].replace(" ", "")


                                ip_format = datetime.datetime.strptime(fields[1], '%Y-%m-%d')
                                date1 = datetime.datetime.strptime(fields[1], '%Y-%m-%d').date()
                                if date1 > today_date:
                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'nav_date': fields[1],
                                                                                   'description': 'Future date is not allowed'}})
                                #data_list.append([fields[0].upper(), fields[1]])

                            except ValueError:

                                upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                               'pms_code': fields[0].upper(),
                                                                               'nav_date': fields[1],
                                                                               'description': 'Incorrect Date Format, should be YYYY-MM-DD'}})




                        data_list.append([fields[0].upper(), fields[1], fields[2]])
                        key = ','.join([fields[0].upper(), fields[1]])
                        try:

                            if key in data_dict_per:
                                amount = data_dict_per[key]
                                total_amount = float(amount) + float(fields[4])
                            else:
                                amount = 0
                                total_amount = float(amount) + float(fields[4])
                            data_dict_per[key] = total_amount
                        except ValueError:
                            upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                           'pms_code': fields[0].upper(),
                                                                           'nav_date': fields[1],
                                                                           'description': 'Incorrect DATA format for % column, should be Numeric'}})

                        upload_count_error = upload_count_error + 1

                        # data_list_per.append([fields[0].upper(), fields[1],fields[4]])
                    if  upload_error_dict:
                        response = HttpResponse(content_type='text/csv')
                        response['Content-Disposition'] = 'attachment; filename="underlying_upload_error.csv"'
                        writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                        writer.writerow(['Row No','PMS Code', 'Nav Date', 'Description'])
                        for record in upload_error_dict.items():
                            csv_error_array = []
                            rowid=record[0]
                            msgtext=record[1]
                            csv_error_array.append(rowid)
                            csv_error_array.append(msgtext['pms_code'])
                            csv_error_array.append(msgtext['nav_date'])
                            csv_error_array.append(msgtext['description'])
                            writer.writerow(csv_error_array)
                        return response

                    aa = len(data_list)
                    # data_list.sort()
                    # new_datalist = list(data_list for data_list, _ in itertools.groupby(data_list))
                    # print(new_datalist)
                    # bb = len(new_datalist)
                    cc = [x for n, x in enumerate(data_list) if x in data_list[:n]]

                    if cc:
                        response = HttpResponse(content_type='text/csv')
                        response['Content-Disposition'] = 'attachment; filename="underlying_upload_error.csv"'
                        writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                        writer.writerow(['Row No', 'PMS Code', 'Nav Date','ISIN', 'Description'])
                        for r in cc:
                            indices = [i for i, x in enumerate(data_list) if x == r]

                            indices = [x + 2 for x in indices]
                            csv_error_list = []
                            rowid = ", ".join(map(str, indices))
                            csv_error_list.append(rowid)
                            csv_error_list.append(r[0])
                            csv_error_list.append(r[1])
                            csv_error_list.append(r[2])
                            csv_error_list.append('Uploaded file has duplicate ISIN data')
                            writer.writerow(csv_error_list)

                        return response

                    else:

                        data_list_per = [k for k, v in data_dict_per.items() if v > 100.00]
                        r_list = []
                        if data_list_per:
                            response = HttpResponse(content_type='text/csv')
                            response['Content-Disposition'] = 'attachment; filename="underlying_upload_error.csv"'
                            writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                            writer.writerow(['PMS Code', 'Nav Date',  'Description'])

                            for ri in data_list_per:
                                r_data = ri.split(",")
                                r_list.append([r_data[0],r_data[1]])


                            for r in r_list:

                                # indices = [i for i, x in enumerate(data_list) if x == r]
                                # indices = [x + 2 for x in indices]
                                csv_error_list = []
                                # rowid = ", ".join(map(str, indices))
                                # csv_error_list.append(rowid)
                                csv_error_list.append(r[0])
                                csv_error_list.append(r[1])
                                # csv_error_list.append(r[2])
                                csv_error_list.append('Sum of holding % for PMS code can not be greater than 100')
                                writer.writerow(csv_error_list)

                            return response
                            # form.errors[
                            #     'document'] = "Sum of PMS code and date should not be greater than 100"
                            # return render(request, self.template_name,
                            #               {'url': '', 'form_error': form.errors, 'data_list_per': data_list_per,
                            #                'underlying': 1})
                        else:
                            error_count = 0

                            try:
                                with transaction.atomic():

                                    upload_error_dict ={}
                                    upload_count_error=2
                                    for line in lines:
                                        fields = line.split(",")
                                        pms_code1 = fields[0].upper()
                                        record_list = PmsDetails.objects.filter(is_active=True,
                                                                                pms_code=pms_code1).first()
                                        if not record_list:
                                            data_dict["pms_code"] = ''
                                            msg = pms_code1 + " - Pms Code Does not exists"
                                            raise IntegrityError

                                        else:
                                            data_dict["pms_code"] = record_list.id

                                        data_dict["nav_date"] = fields[1]
                                        data_dict["isin"] = fields[2]
                                        data_dict["name"] = fields[3]
                                        data_dict["percent"] = round(float(fields[4]), 4)

                                        if len(fields) == 6:
                                            data_dict["mkt_value"] = round(float(fields[5]), 4)

                                        else:
                                            error_count += 1
                                            messages.add_message(request, messages.ERROR, 'Market Value is mandatory. Market Value does not exists')
                                            raise IntegrityError

                                        form = PmsunderlyingUploadInsertForm(data_dict)

                                        if form.is_valid():
                                            try:
                                                data = form.save(commit=False)
                                                data.is_used = 0
                                                data.document = document_url
                                                data.last_modified_by = session_emp_code
                                                data.modified_on = int(time.time())
                                                data.save()
                                            except Exception as e:
                                                upload_error_dict.update(
                                                    {upload_count_error: {'row': upload_count_error,
                                                                          'pms_code': fields[0].upper(),
                                                                          'nav_date': fields[1],
                                                                          'description': e}})
                                                error_count += 1


                                        else:
                                            # form.error['document'] = "Uploaded file has duplicate data"

                                            formdata_str = form.errors.as_json()
                                            formdata = literal_eval(formdata_str)

                                            for key,value in formdata.items():
                                                for x in value:

                                                    erro_msg= key +' : ' + x['message']
                                                    upload_error_dict.update(
                                                        {upload_count_error: {'row': upload_count_error,
                                                                              'pms_code': fields[0].upper(),
                                                                              'nav_date': fields[1],
                                                                              'description': erro_msg}})

                                        upload_count_error = upload_count_error + 1

                                if upload_error_dict:
                                    response = HttpResponse(content_type='text/csv')
                                    response[
                                        'Content-Disposition'] = 'attachment; filename="underlying_upload_error.csv"'
                                    writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                                    writer.writerow(['Row No', 'PMS Code', 'Nav Date', 'Description'])
                                    for record in upload_error_dict.items():
                                        csv_error_array = []
                                        rowid = record[0]
                                        msgtext = record[1]
                                        csv_error_array.append(rowid)
                                        csv_error_array.append(msgtext['pms_code'])
                                        csv_error_array.append(msgtext['nav_date'])
                                        csv_error_array.append(msgtext['description'])
                                        writer.writerow(csv_error_array)
                                    return response

                                            # return render(request, self.template_name,
                                            #               {'url': '', 'form_error': form.errors})
                                    if error_count > 0:
                                        messages.add_message(request, messages.ERROR, 'Underlying uploaded has some error')
                                        raise IntegrityError

                                    else:
                                        messages.add_message(request, messages.SUCCESS,'Underlying uploaded Successfully')
                                else:
                                    messages.add_message(request, messages.SUCCESS, 'Underlying uploaded Successfully')


                            except IntegrityError:
                                messages.add_message(request, messages.ERROR, 'Underlying uploaded has some error')
                            return render(request, self.template_name,
                                          {'url': '', 'form_error': form.errors,'underlying': 1})



        return render(request, self.template_name, {'url':'','form_error':form.errors,'underlying':underlying})


class PmsAutocomplete(View):

    def post(self, request, *args, **kwargs):

        # import pdb
        # pdb.set_trace()

        search_filter = self.request.POST.get('filter', '')
        qs = RiskProfile.objects.none()
        data = {}
        if search_filter:

            qs = PmsOtherProductDetails.objects.filter(oth_productName__istartswith=search_filter).all()
            for i in qs:
                data[i.id] = i.oth_productName

        return JsonResponse(data)
class PmspmsDetails(View):
    def get(self, request, *args, **kwargs):
        try:
            session_emp_code = request.session.get('employee')['employee_code']
        except Exception as e:
            session_emp_code = ''
        pms_name = self.request.GET.get('pms_name', '')
        pms_code = self.request.GET.get('pms_code', '')
        old_pms_code = self.request.GET.get('old_pms_code', '')
        pms_category = self.request.GET.get('pms_category', '')
        normalized_scheme_name = self.request.GET.get('normalized_scheme_name', '')
        vclass = self.request.GET.get('vclass', '')
        recommendation_flag = self.request.GET.get('recommendation_flag', '')

        result = {}
        record_list = PmsOtherProductDetails.objects.filter(oth_productName=pms_name).all()
        if not record_list:
            result['msg'] = 'red_e'
            return JsonResponse(result)


        if old_pms_code =='':
            record_list = PmsDetails.objects.filter(pms_code=pms_code,is_active=True).all()
            if not record_list:

                pms_details = PmsDetails(pms_name=pms_name, pms_code=pms_code, pms_category=pms_category,
                                         is_active=True, last_modified_by=session_emp_code,
                                         normalized_scheme_name=normalized_scheme_name,recommendation_flag=recommendation_flag,vclass=vclass,
                                         modified_on=int(time.time()))
                pms_details.save()
                result['msg'] = 'green_i'
                return JsonResponse(result)
            else:


                record_list = PmsDetails.objects.filter(pms_code=pms_code,pms_name=pms_name,is_active=True).all()
                if not record_list:
                    result['msg'] = "red"
                    return JsonResponse(result)
                else:
                    error_count = 0
                    for record in record_list:
                        try:

                            data = PmsDetails.objects.get(id=record.id)
                            data.pms_name = pms_name
                            data.pms_code = pms_code
                            data.pms_category = pms_category
                            data.last_modified_by = session_emp_code
                            data.modified_on = int(time.time())
                            data.normalized_scheme_name = normalized_scheme_name
                            data.vclass = vclass
                            data.recommendation_flag = recommendation_flag
                            data.is_active = True
                            data.save()
                        except Exception as e:
                            error_count += 1


                    if error_count > 0:
                        result['msg'] = "red"

                    else:
                        result['msg'] = "green"

                    return JsonResponse(result)
        else:

            record_list = PmsDetails.objects.filter(pms_code=pms_code,is_active=True).all()
            if  record_list:
                newrecord_list = PmsDetails.objects.filter(pms_code=pms_code,pms_name=pms_name,is_active=True).all()
                if newrecord_list:

                    error_count = 0
                    for record in newrecord_list:
                        try:

                            data = PmsDetails.objects.get(id=record.id)
                            data.pms_name = pms_name
                            data.pms_code = pms_code
                            data.pms_category = pms_category
                            data.last_modified_by = session_emp_code
                            data.modified_on = int(time.time())
                            data.normalized_scheme_name = normalized_scheme_name
                            data.vclass = vclass
                            data.recommendation_flag = recommendation_flag
                            data.is_active = True
                            data.save()
                        except Exception as e:
                            error_count += 1

                    if error_count > 0:
                        result['msg'] = "red_i"

                    else:
                        result['msg'] = "green"

                    return JsonResponse(result)
                else:
                    result['msg'] = "red"
                    return JsonResponse(result)

            else:
                record_list = PmsDetails.objects.filter(is_active=True, pms_code=old_pms_code).all()
                error_count = 0
                for record in record_list:
                    try:

                        data = PmsDetails.objects.get(id=record.id)
                        data.pms_name = pms_name
                        data.pms_code = pms_code
                        data.pms_category = pms_category
                        data.last_modified_by = session_emp_code
                        data.modified_on = int(time.time())
                        data.normalized_scheme_name = normalized_scheme_name
                        data.vclass = vclass
                        data.recommendation_flag = recommendation_flag
                        data.is_active = True
                        data.save()
                    except Exception as e:
                        error_count += 1

                if error_count > 0 :
                    result['msg'] = "red_i"

                else:
                    result['msg'] = "green"

                return JsonResponse(result)

class GetPmsCode(View):

    def get(self, request, *args, **kwargs):
        try:
            session_emp_code = request.session.get('employee')['employee_code']
        except Exception as e:
            session_emp_code = ''
        pms_name = self.request.GET.get('pms_name', '')

        record_list = PmsDetails.objects.filter(is_active=True,pms_name=pms_name).first()
        result = {}
        if not record_list:
            result['msg'] = ''
        else:

            result['msg'] = record_list.pms_code


        return JsonResponse(result)

class NavUpdate(View):

    def get(self, request, *args, **kwargs):
        try:
            session_emp_code = request.session.get('employee')['employee_code']
        except Exception as e:
            session_emp_code = ''

        # import pdb
        # pdb.set_trace()

        record_list = TmpPmsNavUpload.objects.filter(is_used=0).all().order_by('id')[:100]

        insert_count=0
        update_count=0
        pms_list=[]

        for record in record_list:

            pms_code =record.pms_code
            nav_date =record.nav_date
            nav = record.nav
            temp_id=record.id
            pms_list.append(pms_code)

            is_record_exist = PmsNavUpload.objects.filter(pms_code =pms_code ,nav_date=nav_date).exists()
            if is_record_exist:
                PmsNavUpload.objects.filter(pms_code =pms_code ,nav_date=nav_date).update(nav=nav,last_modified_by=session_emp_code,
                                                                 modified_on=int(time.time()))

                TmpPmsNavUpload.objects.filter(id=temp_id).update(is_used=1,last_modified_by=session_emp_code,modified_on=int(time.time()))
                update_count =update_count+1
            else:
                p = PmsNavUpload(pms_code =pms_code ,nav_date=nav_date,nav=nav,last_modified_by=session_emp_code,
                                                                 modified_on=int(time.time()))
                p.save()
                TmpPmsNavUpload.objects.filter(id=temp_id).update(is_used=1, last_modified_by=session_emp_code,
                                                                  modified_on=int(time.time()))
                insert_count =insert_count+1



        result = {}

        pms_set = list(set(pms_list))
        for i in pms_set:
            PmsDetails.objects.filter(id=i).update(last_modified_by=session_emp_code,modified_on=int(time.time()))


        if not record_list:
            result['msg'] = 'No Record Found'
        else:


            result['msg'] = "Total Inserted Record: %s - Total Updated Record: %s" % (insert_count,update_count)


        return JsonResponse(result)

class PmsManage(ListView):

    template_name = 'pms/list_view.html'

    def get(self, request, *args, **kwargs):
        """
        Return the list of all the active roles data.
        """

        search_filter = self.request.GET.get('filter', '')
        sort_value = self.request.GET.get('sort')
        search_filter_text = '%' + search_filter + '%'
        firstval=sort_value[0]
        if firstval == "-":
            order_by = 'modified_on DESC'
        else:
            order_by = 'modified_on ASC'

        underlyingdata = PmsUnderlyingUpload.objects.values_list('pms_code',flat=True).distinct()


        if search_filter:
            sql = "select d.pms_category,d.id,d.pms_name,d.pms_code," \
                  "d.last_modified_by," \
                  "d.modified_on," \
                  "min(u.nav_date) as min_date, max(u.nav_date) as max_date from pms_nav_upload u RIGHT JOIN pms_details d ON u.pms_code = d.id where d.is_active=1 AND d.pms_code like %s group by d.id order by %s"
            queryset = PmsNavUpload.objects.raw(sql, [search_filter_text,   order_by])
        else:

            sql = "select d.pms_category,d.id,d.pms_name,d.pms_code," \
                  "d.last_modified_by," \
                  "d.modified_on," \
                  "min(u.nav_date) as min_date, max(u.nav_date) as max_date from pms_nav_upload u RIGHT JOIN pms_details d ON u.pms_code = d.id  where d.is_active=1 group by d.id order by %s" %order_by
            queryset = PmsNavUpload.objects.raw(sql)

        paginator = Paginator(queryset, 5)
        try:
            page = int(request.GET.get('page', '1'))
        except:
            page = 1

        try:
            record_list = paginator.page(page)
        except PageNotAnInteger:
            record_list = paginator.page(1)
        except EmptyPage:
            record_list = paginator.page(paginator.num_pages)

            # Get the index of the current page
        index = record_list.number - 1

        # This value is maximum index of pages, so the last page - 1
        max_index = len(paginator.page_range)

        # range of 7, calculate where to slice the list
        start_index = index - 3 if index >= 3 else 0
        end_index = index + 4 if index <= max_index - 4 else max_index

        # new page range
        page_range = paginator.page_range[start_index:end_index]

        # showing first and last links in pagination
        if index >= 4:
            start_index = 1
        if end_index - index >= 4 and end_index != max_index:
            end_index = max_index
        else:

            end_index = None

        return render(request, self.template_name,{'record_list': record_list, 'page_range': page_range,'start_index': start_index,'end_index': end_index,'max_index':max_index,'order_by':order_by,'underlyingdata':underlyingdata})

class NavExport(View):
    def get(self, request, pmscode):
        """
        Return the list of all the active roles data.
        """


        # import pdb
        # pdb.set_trace()
        search_filter=pmscode
        if search_filter:
            sql = "select d.pms_code,u.nav_date,CAST(u.nav AS CHAR) from pms_nav_upload u JOIN pms_details d ON u.pms_code = d.id where d.pms_code = %s "
            # queryset = PmsNavUpload.objects.raw(sql, [search_filter])
            cursor = connection.cursor()
            cursor.execute(sql, [search_filter])
            row = cursor.fetchall()
            result=row
        else:
            result=[]


        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="nav_download.csv"'

        writer = csv.writer(response , quoting=csv.QUOTE_ALL)
        writer.writerow(['PMS Code', 'Nav Date', 'Nav'])

        for record in result:
            writer.writerow(record)

        return response

class PmsUnderlying(View):
    template_name = 'pms/create.html'
    form_class = PmsUnderlyingDocumentForm

    def get(self, request, *args, **kwargs):
        """
        Return the list of all the active roles data.
        """
        # import pdb
        # pdb.set_trace()
        form= PmsUnderlyingDocumentForm()
        return render(request, self.template_name, {'form': form})

    @transaction.atomic
    def post(self, request, *args, **kwargs):

        try:
            session_emp_code = request.session.get('employee')['employee_code']
        except Exception as e:
            session_emp_code = ''
        # form = self.form_class(request.POST)
        if request.method == 'POST':
            # import pdb
            # pdb.set_trace()
            form_class = PmsUnderlyingDocumentForm
            form = PmsUnderlyingDocumentForm(request.POST, request.FILES)
            if form.is_valid():
                csv_file = request.FILES["document"]

                if csv_file.multiple_chunks():
                    form.errors['document'] =  "Uploaded file is too big (%.2f MB)." % (csv_file.size / (1000 * 1000),)
                    return render(request, self.template_name, {'url':'','form_error':form.errors,'underlying':1})
                file_data = csv_file.read().decode("utf-8",'ignore')

                initial_obj = form.save(commit=False)
                initial_obj.save()
                document_url=initial_obj.document.url
                if  file_data =='\n':
                    form.errors['document'] = "Uploaded file can not be  blank"
                    return render(request, self.template_name, {'url': '', 'form_error': form.errors,'underlying':1})

                lines = file_data.split("\n")
                # loop over the lines and save them in db. If error , store as string and then display
                data_dict = {}
                data_list =[]
                # data_list_per = []
                data_dict_per = {}
                lines.remove(lines[0])
                lines = list(filter(None, lines))
                if not lines:
                    form.errors['document'] = "Uploaded file must have one record"
                    return render(request, self.template_name, {'url': '', 'form_error': form.errors,'underlying':1})

                for line in lines:
                    fields = line.split(",")
                    data_list.append([fields[0].upper(),fields[1],fields[2]])
                    key='-'.join([fields[0].upper(), fields[1]])
                    if key in data_dict_per:
                        amount=data_dict_per[key]
                        total_amount = float(amount) + float(fields[4])
                    else:
                        amount = 0
                        total_amount = float(amount) + float(fields[4])

                    data_dict_per[key] = total_amount
                    # data_list_per.append([fields[0].upper(), fields[1],fields[4]])

                aa=len(data_list)
                data_list.sort()
                new_datalist = list(data_list for data_list, _ in itertools.groupby(data_list))
                bb = len(new_datalist)
                if aa != bb:
                    form.errors['document'] = "Uploaded file has duplicate ISIN data"
                    return render(request, self.template_name, {'url': '', 'form_error': form.errors,'underlying':1})
                else:

                    data_list_per = [k for k, v in data_dict_per.items() if v > 100.00]

                    if data_list_per:
                        form.errors[
                            'document'] = "Sum of holding % for PMS code can not be greater than 100"
                        return render(request, self.template_name,
                                      {'url': '', 'form_error': form.errors, 'data_list_per': data_list_per,'underlying':1})
                    else:
                        error_count = 0
                        try:
                            with transaction.atomic():

                                for line in lines:
                                    fields = line.split(",")
                                    pms_code1 = fields[0].upper()
                                    record_list = PmsDetails.objects.filter(is_active=True, pms_code=pms_code1).first()
                                    if not record_list:
                                        data_dict["pms_code"] = ''
                                        msg = pms_code1 + " - Pms Code Does not exists"
                                        raise IntegrityError

                                    else:
                                        data_dict["pms_code"] = record_list.id

                                    data_dict["nav_date"] = fields[1]
                                    data_dict["isin"] = fields[2]
                                    data_dict["name"] = fields[3]
                                    data_dict["percent"] = round(float(fields[4]), 4)


                                    form = PmsunderlyingUploadInsertForm(data_dict)

                                    if form.is_valid():
                                        try:
                                            data = form.save(commit=False)
                                            data.document = document_url
                                            data.last_modified_by = session_emp_code
                                            data.modified_on = int(time.time())
                                            data.save()
                                        except Exception as e:
                                            error_count += 1


                                    else:
                                        # form.error['document'] = "Uploaded file has duplicate data"
                                        return render(request, self.template_name,
                                                      {'url': '', 'form_error': form.errors})
                                if error_count > 0:
                                    msg = "Underlying uploaded has some error"
                                    raise IntegrityError

                                else:
                                    msg = "Underlying uploaded Successfully"




                        except IntegrityError:
                            pass
                            # handle_exception()
                        return render(request, self.template_name, {'url': '', 'form_error': form.errors, 'msg': msg,'underlying':1})






        return render(request, self.template_name, {'url':'','form_error':form.errors,'underlying':1})


class UnderlyingExport(View):
    def get(self, request, pmscode):
        """
        Return the list of all the active roles data.
        """


        # import pdb
        # pdb.set_trace()
        search_filter=pmscode
        if search_filter:
            #sql = "select pms_code,nav_date,isin,name,percent  from pms_underlying_upload  where pms_code = %s "
            sql = "select d.pms_code,u.nav_date,u.isin,u.name,u.percent, u.mkt_value " \
                  "from pms_underlying_upload u JOIN pms_details d ON u.pms_code = d.id " \
                  "where d.pms_code = %s "
            # queryset = PmsNavUpload.objects.raw(sql, [search_filter])
            cursor = connection.cursor()
            cursor.execute(sql, [search_filter])
            row = cursor.fetchall()
            result=row

            # result=PmsUnderlyingUpload.objects.filter(pms_code=search_filter).all()

        else:
            result=[]


        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="underlying_download.csv"'

        writer = csv.writer(response , quoting=csv.QUOTE_ALL)
        writer.writerow(['PMS Code', 'Date', 'ISIN','Name' ,'%', 'Mkt Value'])

        for record in result:
            writer.writerow(record)

        return response


class PmsDataUpload(View):
    template_name = 'pms/dataupload.html'
    def get(self, request, *args, **kwargs):
        """
        Return the list of all the active roles data.
        """
        # import pdb
        # pdb.set_trace()
        #form = PmsdataUploadForm()
        # msg = self.request.GET.get('msg', '')
        # error_color = self.request.GET.get('error_color', '')
        return render(request, self.template_name)

    def return_style_string(self, style_name):
        if style_name == 'GROWTH':
            style = 'Growth'
            return style
        elif style_name == 'BLENDED TOWARDS GROWTH':
            style = 'Blended towards growth'
            return style
        elif style_name == 'BLENDED':
            style = 'Blended'
            return style
        elif style_name == 'BLENDED TOWARDS VALUE':
            style = 'Blended towards Value'
            return style
        elif style_name == 'VALUE':
            style = 'Value'
            return style
        elif style_name == 'MEAN REVERSION':
            style = 'Mean Reversion'
            return style
        elif style_name == 'EARNINGS MOMENTUM':
            style = 'Earnings Momentum'
            return style

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        if request.method == 'POST':

            form = PmsdataUploadForm(request.POST, request.FILES)
            if form.is_valid():
                csv_file = request.FILES["document"]

                if csv_file.multiple_chunks():
                    form.errors['document'] = "Uploaded file is too big (%.2f MB)." % (csv_file.size / (1000 * 1000),)
                    return render(request, self.template_name, {'url': '', 'form_error': form.errors})
                file_data = csv_file.read().decode("utf-8", 'ignore')

                initial_obj = form.save(commit=False)
                initial_obj.save()
                document_url = initial_obj.document
                if file_data == '\n':
                    form.errors['document'] = "Uploaded file can not be  blank"
                    return render(request, self.template_name, {'url': '', 'form_error': form.errors})

                lines = file_data.split("\n")
                # loop over the lines and save them in db. If error , store as string and then display
                data_dict = {}
                data_perf_dict={}
                data_list = []
                lines.remove(lines[0])
                lines = list(filter(None, lines))
                if not lines:
                    form.errors['document'] = "Uploaded file must have one record"
                    return render(request, self.template_name,
                                  {'url': '', 'form_error': form.errors, 'underlying': 1})
                upload_error_dict = {}
                upload_count_error = 2
                for line in lines:

                    fields = line.split(",")
                    fields = fields[:180]
                    if len(fields) != 180:
                        form.errors['document'] = "Incorrect Data in CSV File,Must have 180 columns"
                        return render(request, self.template_name,
                                      {'url': '', 'form_error': form.errors})
                        upload_count_error +=1
                    else:


                        pms_code1 = fields[0].upper()
                        data_list.append(pms_code1)
                        record_list = PmsDetails.objects.filter(is_active=True, pms_code=pms_code1).first()
                        # style_list=['Growth','Blended towards Growth', 'Blended', 'Blended towards Value', 'Value', 'Mean Reversion', 'Earning Momentum']
                        style_list = ['GROWTH', 'BLENDED TOWARDS GROWTH', 'BLENDED', 'BLENDED TOWARDS VALUE', 'VALUE',
                                      'MEAN REVERSION', 'EARNINGS MOMENTUM']
                        style = fields[1].upper()

                        if not record_list:
                            upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                           'pms_code': fields[0].upper(),
                                                                           'description': 'Pms Code does not exists'}})
                            upload_count_error += 1
                        else:

                            today_date = datetime.datetime.now().date()

                            try:
                                fields[2].replace(" ", "")
                                ip_format = datetime.datetime.strptime(fields[2], '%Y-%m-%d')
                                date1 = datetime.datetime.strptime(fields[2], '%Y-%m-%d').date()
                                if date1 > today_date:
                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'description': 'Future date is not allowed'}})
                                #data_list.append([fields[0].upper(), fields[1]])

                            except ValueError:

                                upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                               'pms_code': fields[0].upper(),
                                                                               'description': 'Incorrect Date Format, should be YYYY-MM-DD'}})
                            pms_code = record_list.pms_code
                            pms_category = record_list.pms_category
                            if pms_category == 'Equity':
                                if style !='':
                                    if (style not in style_list):
                                        upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                       'pms_code': fields[0].upper(),
                                                                                       'description': 'Style does not exists'}})
                                        upload_count_error += 1



                                    upload_count_error += 1

                                if fields[28] != '' or fields[29] != '' or fields[30] != '' or fields[31] != '' or fields[32] != '' or fields[33] != ''\
                                        or fields[34] != '' or fields[35] != '' or fields[36] != '' or fields[37] != '' or fields[38] != ''\
                                        or fields[39] != '' or fields[40] != '' or fields[41] != '' or fields[42] != '' or fields[43] != '':

                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'description': 'SOV,AAA & Equivalent,AA & Equivalent,A & Below,Cash & Equivalent,Unrated,Avg Mat (years)'
                                                                                                  ',Mod Dur (years),,Gross YTM (%),Net YTM (%),0 - 1Y,'
                                                                                                  '1 - 3Y,3 - 5Y,5 - 10Y,10Y+,Others  is not applicable'}})
                                    upload_count_error += 1
                                    if fields[65] == '' or fields[66] == '' or fields[67] == '' or fields[68] == '' or \
                                            fields[69] == '':
                                        upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                       'pms_code': fields[0].upper(),
                                                                                       'description': 'G-Sec/ T-Bills,Corp Bonds,Bank CDs,CP,Others is not applicable'}})

                                if fields[70] == '':
                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'description': 'Index Scheme ID value is required'}})
                                    upload_count_error += 1

                            else:

                                if fields[1] != '' :
                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'description': 'Style is not applicable'}})
                                    upload_count_error += 1

                                if fields[19] == '' or fields[20] == '' or fields[21] == '' or fields[22] == '' or \
                                        fields[23] == '' or fields[24] == '' or fields[25] == '' or fields[26] == '' or \
                                        fields[27] == '':
                                    upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                   'pms_code': fields[0].upper(),
                                                                                   'description': 'Information Ratio,Std Dev,Beta,Alpha,Sharpe Ratio,P/E Ratio,P/B Ratio,ROE,Div Yield is not applicable'}})


                                    upload_count_error += 1

                            #if fields[125] == '' or fields[125] == None or fields[125] =='None':
                            if fields[179] == '' or fields[179] == None or fields[179] == 'None':
                                upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                               'pms_code': fields[0].upper(),
                                                                               'description': 'Closed_Flag is required'}})
                                upload_count_error += 1





                if upload_error_dict:
                    response = HttpResponse(content_type='text/csv')
                    response['Content-Disposition'] = 'attachment; filename="Pms_data_upload_error.csv"'
                    writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                    writer.writerow(['Row No', 'PMS Code', 'Description'])
                    for record in upload_error_dict.items():
                        csv_error_array = []
                        rowid = record[0]
                        msgtext = record[1]
                        csv_error_array.append(rowid)
                        csv_error_array.append(msgtext['pms_code'])
                        csv_error_array.append(msgtext['description'])
                        writer.writerow(csv_error_array)
                    return response

                aa = len(data_list)
                # data_list.sort()

                cc = [item for item, count in collections.Counter(data_list).items() if count > 1]

                if cc:

                    response = HttpResponse(content_type='text/csv')
                    response['Content-Disposition'] = 'attachment; filename="Pms_data_upload_error.csv"'
                    writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                    writer.writerow(['Row No', 'PMS Code',  'Description'])
                    for r in cc:
                        indices = [i for i, x in enumerate(data_list) if x == r]
                        indices = [x + 2 for x in indices]
                        csv_error_list = []
                        rowid = ", ".join(map(str, indices))
                        csv_error_list.append(rowid)
                        csv_error_list.append(r)
                        csv_error_list.append('Uploaded file has duplicate data')
                        writer.writerow(csv_error_list)

                    return response
                else:
                    error_count = 0

                    try:
                        with transaction.atomic():
                            upload_error_dict = {}
                            upload_count_error = 2
                            for line in lines:
                                fields = line.split(",")
                                category = 'PMS Strategies'
                                data_dict["pms_code"] = fields[0].upper()
                                data_dict["style"] = self.return_style_string(fields[1].upper())
                                data_dict["category"] = category
                                data_dict["inceptiondate"] = fields[2]
                                data_dict["aum"] = fields[3]
                                data_dict["exitload"] = fields[4]
                                data_dict["expense_ratio"] = fields[5]
                                data_dict["fp_pointer1"] = fields[6]
                                data_dict["fp_pointer2"] = fields[7]
                                data_dict["fp_pointer3"] = fields[8]
                                data_dict["fp_pointer4"] = fields[9]
                                data_dict["fp_pointer5"] = fields[10]
                                data_dict["fm_name"] = fields[11]
                                data_dict["fm_desc"] = fields[12]
                                data_dict["fm_pointer1"] = fields[13]
                                data_dict["fm_pointer2"] = fields[14]
                                data_dict["fm_pointer3"] = fields[15]
                                data_dict["fm_pointer4"] = fields[16]
                                data_dict["fm_pointer5"] = fields[17]
                                data_dict["benchmarkname"] = fields[18]
                                data_dict["information_ratio"] = fields[19]
                                data_dict["std_dev"] = fields[20]
                                data_dict["beta"] = fields[21]
                                data_dict["alpha"] = fields[22]
                                data_dict["sharpe_ratio"] = fields[23]
                                data_dict["pe_ratio"] = fields[24]
                                data_dict["pb_ratio"] = fields[25]
                                data_dict["roe"] = fields[26]
                                data_dict["div_yield"] = fields[27]
                                data_dict["sov"] = fields[28]
                                data_dict["aaa_equivalent"] = fields[29]
                                data_dict["aa_equivalent"] = fields[30]
                                data_dict["a_below"] = fields[31]
                                data_dict["cash_equivalent"] = fields[32]
                                data_dict["unrated"] = fields[33]
                                data_dict["avgmat"] = fields[34]
                                data_dict["mod_dur"] = fields[35]
                                data_dict["gross_ytm"] = fields[36]
                                data_dict["net_ytm"] = fields[37]
                                data_dict["m0_1y"] = fields[38]
                                data_dict["m0_3y"] = fields[39]
                                data_dict["m3_5y"] = fields[40]
                                data_dict["m5_10y"] = fields[41]
                                data_dict["m10y"] = fields[42]
                                data_dict["m_others"] = fields[43]

                                #new added column.
                                data_dict["p1m"] = fields[44]

                                data_dict["p3m"] = fields[45]
                                data_dict["p6m"] = fields[46]
                                data_dict["p1y"] = fields[47]
                                data_dict["p2y"] = fields[48]
                                data_dict["p3y"] = fields[49]
                                data_dict["p5y"] = fields[50]

                                # new added column.
                                data_dict["p7y"] = fields[51]


                                data_dict["since_inception"] = fields[52]
                                data_dict["p_min"] = fields[53]
                                data_dict["p_max"] = fields[54]
                                data_dict["p_avg"] = fields[55]

                                #new added
                                data_dict["p_min_1y"] = fields[56]
                                data_dict["p_max_1y"] = fields[57]
                                data_dict["p_avg_1y"] = fields[58]
                                data_dict["p_min_2y"] = fields[59]
                                data_dict["p_max_2y"] = fields[60]
                                data_dict["p_avg_2y"] = fields[61]
                                data_dict["p_min_3y"] = fields[62]
                                data_dict["p_max_3y"] = fields[63]
                                data_dict["p_avg_3y"] = fields[64]


                                data_dict["gsec_tbills"] = fields[65]
                                data_dict["crop_bonds"] = fields[66]
                                data_dict["bankcd"] = fields[67]
                                data_dict["cp"] = fields[68]
                                data_dict["others"] = fields[69]
                                data_dict["benchmarkshortcode"] = fields[70]
                                #data_dict["bmk_mapped"] = fields[60]
                                data_dict["is_open_close_flag"] = fields[179]
                                # add file name
                                data_dict["document_name"] = csv_file






                                form = PmsDataUploadInsertForm(data_dict)

                                if form.is_valid():

                                    try:
                                        try:
                                            session_emp_code = request.session.get('employee')['employee_code']
                                        except Exception as e:
                                            session_emp_code = ''
                                        data = form.save(commit=False)

                                        data.document = document_url
                                        data.is_used  = 0
                                        data.last_modified_by = session_emp_code
                                        data.modified_on = int(time.time())
                                        data.save()
                                    except Exception as e:
                                        upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                       'pms_code': fields[0].upper(),
                                                                                       'description': e}})
                                        # msg = "Pms Data has form some error"
                                        error_count += 1
                                        # error_color='red'
                                        messages.add_message(request, messages.ERROR, 'Pms Data has form some error')
                                        raise IntegrityError

                                else:

                                    formdata_str = form.errors.as_json()
                                    formdata = literal_eval(formdata_str)

                                    for key, value in formdata.items():
                                        for x in value:
                                            erro_msg = key + ' : ' + x['message']
                                            upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                           'pms_code': fields[0].upper(),
                                                                                           'description': erro_msg}})
                                        raise IntegrityError

                                    # upload_count_error = upload_count_error + 1
                                    #
                                    # msg = "Pms Data has form some error"
                                    # error_color = 'red'
                                    # print(form.errors)
                                    # return render(request, self.template_name,
                                    #               {'url': '', 'form_error': form.errors,'msg': msg, 'error_color': error_color})

                                #new added.

                                #pms_performance start
                                del_query = "delete from pms_performance_data where pms_code=%s"
                                cursor = connection.cursor()
                                cursor.execute(del_query, [fields[0].upper()])
                                query = "INSERT INTO pms_performance_data (pms_code,per_date,gytm,mod_dur) VALUES "

                                for i in range(71,177,3):

                                    if (fields[i+1] == "" or fields[i+2] == "" or fields[i] == "" ) or (isinstance(fields[i+1], (int, float)) == True and isinstance(fields[i+2], (int, float)) == True):
                                        if  fields[i]  in ['None', None, '']:
                                            fields[i] = 'NULL'
                                        if  fields[i+1]  in ['None', None, '']:
                                            fields[i+1] = 'NULL'
                                        if  fields[i+2]  in ['None', None, '']:
                                            fields[i+2] = 'NULL'
                                        query = query +"('"+fields[0].upper()+"','"+fields[i]+"',"+fields[i+1]+","+fields[i+2]+"),"
                                    else:
                                        upload_error_dict.update({upload_count_error: {'row': upload_count_error,
                                                                                       'pms_code': fields[0].upper(),
                                                                                       'description': "Datatype mismatched."}})

                                query = query.rstrip(',')
                                cursor = connection.cursor()
                                cursor.execute(query)
                                #pms perforamnce data stop.

                    except IntegrityError:
                        pass

                    if upload_error_dict:
                        response = HttpResponse(content_type='text/csv')
                        response['Content-Disposition'] = 'attachment; filename="Pms_data_upload_error.csv"'
                        writer = csv.writer(response, quoting=csv.QUOTE_ALL)
                        writer.writerow(['Row No', 'PMS Code', 'Description'])
                        for record in upload_error_dict.items():
                            csv_error_array = []
                            rowid = record[0]
                            msgtext = record[1]
                            csv_error_array.append(rowid)
                            csv_error_array.append(msgtext['pms_code'])
                            csv_error_array.append(msgtext['description'])
                            writer.writerow(csv_error_array)
                        return response

                    if error_count > 0:
                        messages.add_message(request, messages.ERROR, 'Pms Data  has some error')
                        raise IntegrityError

                    else:
                        messages.add_message(request, messages.SUCCESS, 'Pms Data uploaded Successfully')






                    return render(request, self.template_name, {'url': '', 'form_error': form.errors})


            else:
                pass
                print(form.errors)

        return render(request, self.template_name, {'url': '', 'form_error': form.errors})

class PmsDataManage(ListView):

    template_name = 'pms/pmsdata_list_view.html'

    def get(self, request, *args, **kwargs):
        """
        Return the list of all the active roles data.
        """

        search_filter = self.request.GET.get('filter', '')
        sort_value = self.request.GET.get('sort')
        search_filter_text = '%' + search_filter + '%'
        firstval=sort_value[0]
        if firstval == "-":
            order_by = 'uploaded_on DESC'
        else:
            order_by = 'uploaded_on ASC'

        if search_filter:
            queryset = FileUploadHistory.objects.filter(document_name__icontains=search_filter).all().order_by(sort_value)
        else:

            queryset = FileUploadHistory.objects.all().order_by(sort_value)
        paginator = Paginator(queryset, 5)
        try:
            page = int(request.GET.get('page', '1'))
        except:
            page = 1

        try:
            record_list = paginator.page(page)
        except PageNotAnInteger:
            record_list = paginator.page(1)
        except EmptyPage:
            record_list = paginator.page(paginator.num_pages)

            # Get the index of the current page
        index = record_list.number - 1

        # This value is maximum index of pages, so the last page - 1
        max_index = len(paginator.page_range)

        # range of 7, calculate where to slice the list
        start_index = index - 3 if index >= 3 else 0
        end_index = index + 4 if index <= max_index - 4 else max_index

        # new page range
        page_range = paginator.page_range[start_index:end_index]

        # showing first and last links in pagination
        if index >= 4:
            start_index = 1
        if end_index - index >= 4 and end_index != max_index:
            end_index = max_index
        else:

            end_index = None

        return render(request, self.template_name,{'record_list': record_list, 'page_range': page_range,'start_index': start_index,'end_index': end_index,'max_index':max_index,'order_by':order_by})

class PmsdataDownload(ListView):

    def get(self, request, fileurl):
        document_path = ''
        record_list = FileUploadHistory.objects.filter(id=fileurl).first()
        if record_list:
            document_path = record_list.document
        file_name = 'pms_data_'+fileurl+'.csv'
        file_path = os.path.join(settings.MEDIA_ROOT, document_path)
        if os.path.exists(file_path):
            with open(file_path, 'rb') as fh:
                response = HttpResponse(fh.read(),content_type="text/csv")
                response['Content-Disposition'] = 'inline; filename=' + file_name
                return response
        else:
            messages.add_message(request, messages.ERROR, 'File path is not exists')
            return redirect('/backend/pms_data_upload')


class DeletePms(View):
    """
        This class will covers the delete view of PMS Cose.
    """

    def get(self, request, pms_id):
        """
        This method will deactivate the passed pms_code.
        :param request:
        :param footer_id:
        :return: Return status as 200 if is_activate gets update successfully as False else it will
                return status as 400 if there is any
        """
        try:
            session_emp_code = request.session.get('employee')['employee_code']
        except Exception as e:
            session_emp_code = ''

        data = {}

        inactive_pms = PmsDetails.objects.filter(id=pms_id).update(is_active=False, last_modified_by=session_emp_code,
                                                                     modified_on=int(time.time()))

        # data = {}
        if inactive_pms:
            data['message'] = 1

        else:
            data['message'] = 0

        return JsonResponse(data)

####################################################

def chunkIt(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg

    return out


def divide_chunks(l, n):
    # looping till length l
    for i in range(0, len(l), n):
        yield l[i:i + n]

def Repeat(x):
    _size = len(x)
    repeated = []
    for i in range(_size):
        k = i + 1
        for j in range(k, _size):
            if x[i] == x[j] and x[i] not in repeated:
                repeated.append(x[i])
    return repeated

def Isunique_question_answer(questions_name,answer_list,score_list,answer_list_len,score_list_len,id):
    questions_name = questions_name.strip()
    if id == 0:
        quetion_dict = RiskProfileQuestionnaire.objects.filter(questions__iexact=questions_name).all()
    else:
        quetion_dict = RiskProfileQuestionnaire.objects.filter(questions__iexact=questions_name).exclude(
            id__in=[id]).all()

    quetion_dict_length = len(quetion_dict)
    if quetion_dict_length == 0:
        return 1
    else:
        matchcount = 0
        for record in quetion_dict:
            question_id = record.id
            new_answer_list = RiskProfileQuestionAnswer.objects.values_list('answer', flat=True).filter(question_id=question_id).all()
            new_answer_list = list(new_answer_list)
            if set(new_answer_list) == set(answer_list) :
                matchcount =matchcount+1
                break
            else:
                pass


        if matchcount == 0 :

            return 1
        else:
            return 0

def handle_uploaded_file(request):
    save_path = os.path.join(settings.MEDIA_ROOT, 'uploads', request.FILES['file'])
    path = default_storage.save(save_path, request.FILES['file'])
    return default_storage.path(path)











