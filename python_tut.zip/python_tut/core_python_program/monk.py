class A:

    def func(self): 
        print("func() is being called")