

def add_two(a,b):

    c=a+b
    return c
def op(a):
    return a

#fun_arg=add_two(10,20)

result=op(add_two(10,20))
print(result)
#print(result(10,20))

def add_two1():
    a=10
    b=20
    c=a+b
    return c
def op1(a):
    return a

#fun_arg=add_two(10,20)

result=op1(add_two1)
print(result)
print(result())

