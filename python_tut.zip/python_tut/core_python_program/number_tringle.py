num=4
for i in range(1,num+1):
    space_count = num - i
    print(' '*(space_count),end='')
    for j in range(i,0,-1):
        print(j,end='')
    for j in range(1+1,i+1):
        print(j,end='')
        
    print(' '*space_count,end='')
    print()