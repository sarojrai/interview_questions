def add(a,b):
    assert(a>b)
    assert(b>a)
    print(a/b)
add(4,0)

--------------
class A:
    def __init__(self,s):
        self.s = s
        
    def print(self):
        #pass
        print(self.s)
a = A('john')
a.print()

## output 
john


class A:
    def __init__(self,s):
        self.s = s
        
    def print(s):
        #pass
        print(s)
a = A('john')
a.print()


## output 
<__main__.A object at 0x7f33c00a3630>

class A:
    def __init__(self,s):
        self.s = s
    def print(self):
        #pass
        print(self.s)
a = A('john')
a.print()

## output 
john



class A:
    def __init__(self,s):
        self.s = s
        
    def print(s):
        pass
        #print(s)
a = A('john')
a.print()

## output 


class A:
    def __init__(self,s):
        self.s = s
        
    def print():
        pass
        #print(s)
a = A('john')
a.print()


## output 
Traceback (most recent call last):
  File "main.py", line 11, in <module>
    a.print()
TypeError: print() takes 0 positional arguments but 1 was given

