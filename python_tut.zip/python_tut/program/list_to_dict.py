import math
l = ['k1', 'v1', 'k2', 'v2', 'k3', 'v3']
print(l)
#m = [ dict([(l[i], l[i+1]) for i in range(0, len(l), 2)])]
m = dict([(l[i], l[i+1]) for i in range(0, len(l), 2)])
print(m)

####
print('square')
l = [1, 3, 5, 7, 9, 11, 13, 15]
result = [i**2 for i in l]
result1 =map(math.pow, range(1,11), [2]*10)
print(result)
print(result1)
print('------------')
def outerFn():
    a = "ameet"
    def innerFn():
       print(a)
