# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks
    def msg(self):
        print(self.name+ " got " + self.marks, "%")
    @classmethod
    def get_per(cls, name, marks):
        return cls(name , str((int(marks)/600)*100))
    @staticmethod
    def get_age(age):
        if age < 17:
            print("belong to school")
        else:
            print("don't belong to school")

s2= Student.get_per("ram","93")
s2.msg()

            
