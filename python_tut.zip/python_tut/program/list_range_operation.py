#!/usr/bin/python

list1 = ['physics', 'chemistry', 1997, 2000];
list2 = [1, 2, 3, 4, 5, 6, 7 ];
print "list1[0]: ", list1[0]
print "list2[1:5]: ", list2[1:5]
print "list2: ", list2[1:5:-2]
print "list2: ", list2[1:5:-1]
#print "list2: ", list2[1:5:0]  // error
print "list2: ", list2[9:1:-2]
print "list2: ", list2[10:1:-2]
print "list2: ", list2[5:-1:-2]
print "list2: ", list2[5:1:-2]
print "list2: ", list2[5:1:2]
print "list2: ", list2[5:0:-2]

"""
--oputput---
list1[0]:  physics
list2[1:5]:  [2, 3, 4, 5]
list2:  []
list2:  []
list2:  [7, 5, 3]
list2:  [7, 5, 3]
list2:  []
list2:  [6, 4]
list2:  []
list2:  [6, 4, 2]
"""
