def outerFn():
    a = "ameet"
    #print(a)
    def innerFn(a):
        print(a)
    innerFn(a)

outerFn()

    
