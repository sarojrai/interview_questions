
#output_list = [output_exp for var in input_list if (var satisfies this condition)]

input_list = [1, 2, 3, 4, 4, 5, 6, 7, 7] 
  
  
evenlist_using_comp = [var for var in input_list if var % 2 == 0] 
  
print("Output Even List using list comprehensions:", evenlist_using_comp) 
oddlist_using_comp = [var for var in input_list if var % 2 != 0] 
print("Output Odd List using list comprehensions:", oddlist_using_comp)

list_using_comp = [var**2 for var in range(1, 10)] 
  
print("Output List using list comprehension:",  
                              list_using_comp)  
