#Python | Convert a list to dictionary

#Method #1 : dict comprehension
def Convert(lst):
    res_dct = {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
    return res_dct
         
# Driver code
lst = ['a', 1, 'b', 2, 'c', 3]
print(Convert(lst))
#output
#{'a': 1, 'b': 2, 'c': 3}

#Method #2 : Using zip() method
#First create an iterator, and initialize it to variable ‘it’. Then use zip method, to zip keys and values together. Finally typecast it to dict type.

# Python3 program to Convert a 
# list to dictionary
 
def Convert(a):
    it = iter(a)
    res_dct = dict(zip(it, it))
    return res_dct
         
# Driver code
lst = ['a', 1, 'b', 2, 'c', 3]
print(Convert(lst))
#output
#{'a': 1, 'b': 2, 'c': 3}
