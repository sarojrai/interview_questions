"""
Python Dictionary Methods

Python has a set of built-in methods that you can use on dictionaries.

Method	Description
clear()	Removes all the elements from the dictionary
copy()	Returns a copy of the dictionary
fromkeys()	Returns a dictionary with the specified keys and value
get()	Returns the value of the specified key
items()	Returns a list containing a tuple for each key value pair
keys()	Returns a list containing the dictionary's keys
pop()	Removes the element with the specified key
popitem()	Removes the last inserted key-value pair
setdefault()	Returns the value of the specified key. If the key does not exist: insert the key, with the specified value
update()	Updates the dictionary with the specified key-value pairs
values()	Returns a list of all the values in the dictionary

"""

# -- Return the dictionary's key-value pairs:
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.items()
for state in x: 
    print(state)

print(x)

# -- Output:

# ('brand', 'Ford')
# ('model', 'Mustang')
# ('year', 1964)
# dict_items([('brand', 'Ford'), ('model', 'Mustang'), ('year', 1964)])

#  --Create a dictionary with 3 keys, all with the value 0:

x = ('key1', 'key2', 'key3')
y = 0

thisdict = dict.fromkeys(x, y)
print(thisdict)

# -- Output:
# ['key1': 0, 'key2': 0, 'key3': 0]

# -- Return the keys:
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.keys()

print(x)
# -- Output:
# dict_keys(['brand', 'model', 'year'])

# Remove "model" from the dictionary:
 car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

car.pop("model")

print(car)

# -- Output:
# {'brand': 'Ford', 'year': 1964}

# Remove the last item from the dictionary:
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

car.popitem()

print(car)

# -- Output:
# {'brand': 'Ford', 'model': 'Mustang'}

# set default
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

car1 = {
  "brand": "Ford",
  "year": 1964
}

x = car.setdefault("model", "Bronco")
print(x)

y = car1.setdefault("model", "Bronco")
print(y)

# -- Output:
# Mustang
# Bronco

# --Return the values:
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.values()

print(x)
# -- Output:
#dict_values(['Ford', 'Mustang', 1964])

#The get() method returns the value of the item with the specified key.

car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.get("model1")
print(car['model'])
print(x)
# -- Output:
#Mustang
#Non

# print(car['model1']) --- keyerror

# Insert Or update an item to the dictionary:
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

car.update({"color": "White"})
car.update({"model": "Mustang1"})

print(car)
# -- Output:
{'brand': 'Ford', 'model': 'Mustang1', 'year': 1964, 'color': 'White'}

# clear the dict
car =	{
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

car.clear()

print(car)

# -- Output:
{}

# Copy the car dictionary:

car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.copy()

print(x)
# -- Output
#{'brand': 'Ford', 'model': 'Mustang', 'year': 1964}

