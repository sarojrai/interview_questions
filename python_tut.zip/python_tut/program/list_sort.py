
from functools import reduce
vegetables = ['squash', 'pea', 'carrot', 'potato']

new_list = sorted(vegetables)

# new_list = ['carrot', 'pea', 'potato', 'squash']
print(new_list)

# vegetables = ['squash', 'pea', 'carrot', 'potato']
print(vegetables)

vegetables.sort()

# vegetables = ['carrot', 'pea', 'potato', 'squash']
print(vegetables)
a=filter(None, ['', 0, 2, 1, 3])
print(a)
print("---------")
def add(x,y):
    
    return x + y
b=reduce(add, [1,2,3,4])
print(b)
