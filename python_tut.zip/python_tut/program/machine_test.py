b={'1':2,'1':2}     
print (b['1'])  #2

print (len(r'1\n\2\t3\b'))  #10

ab ='abcdefghijklmnop'.find('jkl')
print(ab)  #9

def city():
    print("hhh")


print (city)
city()                       #  <function city at 0x7fcacfce6e18>
			      #hhh

s ={1,2,4,5,8}    # {1, 2, 3, 4, 5, 8}
s.add(3)
print(s)



a= {5,6,7}
a.update([3,4])    #-------------->  {3, 4, 5, 6, 7}
print(a)
numbers = (1, 2, 3, 4) 
result = map(lambda x: x + x, numbers)
print("--map--") 
print(result) 
print("--map list--") 
print(list(result))#--map--#<map object at 0x7f8210f903a0>#--map list--#[2, 4, 6, 8]
 
#import numpy as np
#x =[1,2,3,4]
#r =np.correlate(x,x,mode='full')
#print(r) # [ 4 11 20 30 20 11  4]


seq =[111, 1, 8, 4, 5,0,4,21,10,1]
f_result = filter(lambda x: x !=3 , set(seq))
print(f_result)
print(list(f_result))   ## 0, 1, 4, 5, 8, 10, 111, 21]
#print(f_result.astype('float32')) # AttributeError: 'filter' object has no attribute 'astype'

--------------python2***************
#print 17 /2 %2 * 3**3   ---->0

#print len(r'1\n2\t3\b')   ---------> 9

#str ="Lorem text"
#print str.split()[2:2]  ----------> []

#print "hellow 'world'"   ----------> hellow 'world'


#print(f_result.astype('float32'))  
listofTuples = [("Hello" , 7), ("hi" , 10), ("there" , 45),("at" , 23),("this" , 77)]
#wordFrequency = dict(listofTuples)  




#---------------->
				
#<filter object at 0x7f449dc4e748>
#raceback (most recent call last):
#File "main.py", line 26, in <module>
#    print(f_result.astype('float32'))
#AttributeError: 'filter' object has no attribute 'astype'


#-----------------******************--------------
#on3 machine_test.py 
#2
#10
#9
#<function city at 0x7f82110ae1f0>
#hhh
#{1, 2, 3, 4, 5, 8}
#{3, 4, 5, 6, 7}
#--map--
#<map object at 0x7f8210f903a0>
#--map list--
#[2, 4, 6, 8]
#<filter object at 0x7f8210ff0dc0>


