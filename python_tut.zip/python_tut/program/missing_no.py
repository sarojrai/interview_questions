def getMissingNo(A): 
    n = len(A) 
    total = (n + 1)*(n + 2)/2
    sum_of_A = sum(A) 
    return total - sum_of_A 
# Driver program to test above function 
A = [1, 2, 4, 3, 6] 
miss = getMissingNo(A) 
print(miss) 
# This code is contributed by Pratik Chhajer 


# A binary search based program to find  
# the only missing number in a sorted  
# in a sorted array of distinct elements  
# within limited range 
def search(ar, size): 
    a = 0
    b = size - 1
    mid = 0
    while b > a + 1: 
        mid = (a + b) // 2
        if (ar[a] - a) != (ar[mid] - mid): 
            b = mid 
        elif (ar[b] - b) != (ar[mid] - mid): 
            a = mid 
    return ar[mid] + 1
  
# Driver Code 
a = [1, 2, 4, 5, 6, 8] 
n = len(a) 
  
print("Missing number:", search(a, n)) 
  
# This code is contributed 
# by Mohit Kumar 


### multiple number
a = [1,3,4,5, 7,8, 9, 10]
b = [x for x in range(a[0], a[-1] + 1)]
#b = [x for x in range(10)]
print('-----')
#print(a[-1] + 1)
#print(b)
a = set(a)

print('missing number are:')
print (list(a ^ set(b)))

### using itrator tool
a=[1,2,3,4,7,8,10]
from itertools import imap, chain
from operator import sub
print('missing number using missing number')
print list(chain.from_iterable((a[i] + d for d in xrange(1, diff))
                        for i, diff in enumerate(imap(sub, a[1:], a))
                        if diff > 1))

print('Method #1 : List comprehension')
def find_missing(lst): 
    return [x for x in range(lst[0], lst[-1]+1)  
                               if x not in lst] 
  
# Driver code 
lst = [1, 2, 4, 6, 7, 9, 10] 
print(find_missing(lst)) 

print('Method #2 : List comprehension using zip()')
def find_missing(lst): 
    return [i for x, y in zip(lst, lst[1:])  
        for i in range(x + 1, y) if y - x > 1] 
  
# Driver code 
lst = [1, 2, 4, 6, 7, 9, 10] 
print(find_missing(lst)) 

print('Method #3 : Using set')
def find_missing(lst): 
    return sorted(set(range(lst[0], lst[-1])) - set(lst)) 
  
# Driver code 
lst = [1, 2, 4, 6, 7, 9, 10] 
print(find_missing(lst)) 
print('Method #4 : Using difference()')
def find_missing(lst): 
    start = lst[0] 
    end = lst[-1] 
    return sorted(set(range(start, end + 1)).difference(lst)) 
  
# Driver code 
lst = [1, 2, 4, 6, 7, 9, 10] 
print(find_missing(lst)) 

