
# Python program to show the order 
# in which methods are resolved 
  
class A: 
    def rk(self): 
        print(" In class A") 
class B: 
    def rk(self): 
        print(" In class B") 
  
# classes ordering 
class C(B, A): 
    def __init__(self): 
        print("Constructor C") 
  
r = C() 
  
# it prints the lookup order  
#print(r.__mro__) 
print(C.mro()) 
print(r.rk())  #In class B

## output
""" 
## when class C(A ,B): 
Constructor C
[<class '__main__.C'>, <class '__main__.A'>, <class '__main__.B'>, <class 'object'>]


## when class C(B ,A): 

Constructor C
[<class '__main__.C'>, <class '__main__.B'>, <class '__main__.A'>, <class 'object'>]
"""



