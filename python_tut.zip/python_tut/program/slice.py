pyString = 'Python'

# contains indices (0, 1, 2)
# i.e. P, y and t
sObject = slice(3)

print(pyString[sObject])

# contains indices (1, 3)
# i.e. y and h
#sObject = slice(0, 5, 2)
sObject = slice(1, 5, 2)
#sObject = slice(1, 6, 2)
#print(sObject)
print(pyString[sObject])
