
class ABase: 
    def rk(self): 
        print(" In class ABase") 
class A: 
    def rk(self): 
        print(" In class A") 
class B(ABase): 
    def rk1(self): 
        print(" In class B") 
 
#class B: 
#    def rk(self): 
#        print(" In class B") Constructor C
[<class '__main__.C'>, <class '__main__.B'>, <class '__main__.ABase'>, <class '__main__.A'>, <class 'object'>]
 In class ABase
None

  
# classes ordering 
class C(B, A): 
    def __init__(self): 
        print("Constructor C") 
  
r = C() 
  
# it prints the lookup order  
#print(r.__mro__) 
#print(C.mro()) 
print(r.rk())

#output

#Constructor C
#[<class '__main__.C'>, <class '__main__.B'>, <class '__main__.ABase'>, <class '__main__.A'>, <class 'object'>]
#In class ABase
#None

