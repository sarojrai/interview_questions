def uppercase_decorator(function):
    def wrapper():
        func = function()
        print(func)
        make_uppercase = func.upper()
        print('aa')
        return make_uppercase

    return wrapper

def split_string(function):
    
    def wrapper():
        func = function()
        
        print(func)
        splitted_string = func.split()
        print('bb')
        return splitted_string

    return wrapper

@split_string
@uppercase_decorator
def say_hi():
    print("first")
    print('cc')
    return 'hello there'
#a=say_hi()
print(say_hi())

### So the order of checks with two decorators has become:
# split_string
# uppercase_decorator
